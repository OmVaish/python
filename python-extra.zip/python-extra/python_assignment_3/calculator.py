choice=int(input(" 1. + \t 2. - \t 3. * \t 4. / \t 5. %  \n Enter your choice: "))
a=int(input("Enter a:"))
b=int(input("Enter b:"))
if choice==1:
    print("Sum is:",a+b)
elif choice==2:
    print("Difference is:",a-b)
elif choice==3:
    print("Product is:",a*b)
elif choice==4:
    print("Quotient is:",a/b)
elif choice==5:
    print("Remainder is:",a%b)
else:
    print("Invalid choice")