a_list = [34,56,6,777,1,2,3,4,5,7,8,9,10]
print("Max :",max(a_list))
print("Min :",min(a_list))