str=input("Enter a string:")
if str==str[::-1]:
    print("Palindrome")
else:
    print("Not a palindrome")
