a=int(input("Enter a :"))
b=int(input("Enter b :"))
c=int(input("Enter c :"))
d=b**2-4*a*c
if d>0:
    r1=(-b+d**0.5)/(2*a)
    r2=(-b-d**0.5)/(2*a)
    print("The roots are",r1,"and",r2)
elif d==0:
    r1=-b/(2*a)
    print("The root is",r1)
else:
    print("The roots are imaginary")