n=int(input("Enter n:"))
r=int(input("Enter r:"))
def fact(n):
    if n==0:
        return 1
    else:
        return n*fact(n-1)
print("nCr is:",fact(n)//(fact(r)*fact(n-r)))