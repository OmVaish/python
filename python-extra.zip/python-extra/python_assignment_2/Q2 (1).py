def square(x):
    '''Returns the square of a number.'''
    return x * x

def cube(x):
    '''Returns the cube of a number.'''
    return x * x * x

def main():
    num1= int(input("Enter a number: "))
    assert num1 > 0, "The number must be greater than 0."

    print("Square ",square(num1))
    print(square.__doc__)

    num2= int(input("Enter a number: "))
    assert num2 > 0, "The number must be greater than 0."
    
    print("Cube ",cube(num2))
    print(cube.__doc__)

if __name__ == "__main__":
    main()