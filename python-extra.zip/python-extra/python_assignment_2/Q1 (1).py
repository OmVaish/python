def areaOfTriangle(base,height):
    '''Returns the area of a triangle.'''
    return 1/2 * base * height

def areaOfRectangle(length,width):
    '''Returns the area of a rectangle.'''
    return length * width

def areaOfSquare(length):
    '''Returns the area of a square.'''
    return length * length

def main():
    base = int(input("Enter the length of the base: "))
    assert base > 0, "The base must be greater than 0."

    height = int(input("Enter the height of the triangle: "))
    assert height > 0, "The height must be greater than 0."

    print(areaOfTriangle(base, height))

    print(areaOfTriangle.__doc__)

    length = int(input("Enter the length of the rectangle: "))
    assert length > 0, "The length must be greater than 0."

    breadth = int(input("Enter the breadth of the rectangle: "))
    assert breadth > 0, "The breadth must be greater than 0."

    print(areaOfRectangle(length, breadth))

    print(areaOfRectangle.__doc__)

    side = int(input("Enter the side of the square: "))
    assert side > 0, "The side must be greater than 0."

    print(areaOfSquare(side))
    
    print(areaOfSquare.__doc__)

if __name__ == "__main__":
    main()