#defining my function taking string as a parameter
def vowels(A):
    vowels = 0 
    for i in A:
        if(i == 'a' or i == 'e' or i == 'o' or i == 'i' or i == 'u'):
            vowels = vowels+1
    return vowels        
        
inp = input("ENTER ANY STRING : ")
print("Number of vowels in ",inp , " is ",vowels(inp.lower()))    