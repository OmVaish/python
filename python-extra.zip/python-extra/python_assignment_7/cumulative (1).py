#defining my function taking list as a paramter
def myFunction(lst):  
    for i in range(0,n):
        sum = 0
        for j in range(0,i+1):
            sum += lst[j]
        lst[i] = sum  
    return lst          

lst = []       #initialising list
n = int(input("Enter number of elements : "))

for i in range(0,n):       #taking values input of list
    ele = int(input())
    lst.append(ele)
    
print("Original list : " ,lst)    
lst1 = myFunction(lst)    #calling myFunction
print("Cumulative list : ", lst1)