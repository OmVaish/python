#defining my function taking list as a paramter
def myFunction(lst): 
    res = [*set(lst)]   #using set pre-defined function for removing duplicates
    return res

lst = []       #initialising list
n = int(input("Enter number of elements : "))

for i in range(0,n):       #taking values input of list
    ele = int(input())
    lst.append(ele)
    
print("Original list : " ,lst)  
res = myFunction(lst)    #calling myFunction 
print("List after removing duplicates : " , res)