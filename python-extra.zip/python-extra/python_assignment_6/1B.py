x = 'abcd'
for i in x:
    print(i.upper())