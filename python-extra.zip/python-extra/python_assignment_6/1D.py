x = 'abcd'
for i in range(len(x)):
    print(i)