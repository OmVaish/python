i=1
while True:
    if i%3 == 0:
        break
    print(i)
    i+=1